﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;


namespace PlotModule
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        private PlotReceiver pr;
        public Window1()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            pr = new PlotReceiver();
            pr.checklist();
            Plot plotobj = new Plot();
            plotobj.Command = "plot";
            plotobj.Data = new double[,] { { 10, 3, 5, 10, 2 } };
            plotobj.Dimensions = 2;
            plotobj.ScaleMode = 4;
            plotobj.X_Fact = 1;
            plotobj.Y_Fact = 1;
            plotobj.PlotTitle = "FirstPlot";
            Plot subplotobj = new Plot();
            subplotobj.Command = "subplot";
            subplotobj.Data = new double[,] { { -10, 1, 2, 4, 2 } };
            subplotobj.Dimensions = 2;
            subplotobj.ScaleMode = 1;
            subplotobj.X_Fact = 1;
            subplotobj.Y_Fact = 1;
            subplotobj.PaneNum = 2;
            subplotobj.PlotTitle = "second plot";
            Plot subplotobj3 = new Plot();
            subplotobj3.Command = "subplot";
            subplotobj3.Data = new double[,] { { 10, 1, 20, 4, 2 } };
            subplotobj3.Dimensions = 2;
            subplotobj3.ScaleMode = 2;
            subplotobj3.X_Fact = 1;
            subplotobj3.Y_Fact = 1;
            subplotobj3.PaneNum = 4;
            subplotobj3.PlotTitle = "Third Plot";
            Plot plot3d = new Plot();
            plot3d.Command = "plot3D";

            pr.writetolist(plot3d);
           //pr.writetolist(plotobj);
            pr.writetolist(subplotobj);
           
            
           // pr.writetolist(subplotobj3);

            /*Thread.Sleep(5000);
            Plot subplotobj4 = new Plot();
            subplotobj4.Command = "subplot";
            subplotobj4.Data = new double[,] { { -10, -1, -20, -4, -2 } };
            subplotobj4.Dimensions = 2;
            subplotobj4.ScaleMode = 1;
            subplotobj4.X_Fact = 1;
            subplotobj4.Y_Fact = 1;
            subplotobj4.PaneNum = 4;
            subplotobj4.PlotTitle = "Fourth Plot";
            pr.writetolist(subplotobj4);
            Plot plotobj1 = new Plot();
            plotobj1.Command = "plot Again";
            plotobj1.Data = new double[,] { { -10, -1, 20, 4, 2 } };
            plotobj1.Dimensions = 2;
            plotobj1.ScaleMode = 1;
            plotobj1.X_Fact = 1;
            plotobj1.Y_Fact = 1;
            plotobj1.PaneNum = 3;
            plotobj1.PlotTitle = "Full Plot";*/ //commented now 
            //Paint p = new Paint(canvas1);
            //List<double> plist = new List<double>();
            //for (int i = -10; i < 10; i++)
            //{
            //    plist.Add(i + 0.3);
            //}
            //double[] plist1 = new double[] { 6.4, 2.2, 6.2, 7.7, 4.0, -6.0, 8.5, 60.4, 8, 75, -4, 32 };
            //double[] plist2 = new double[] { -5, -30, -5.7, -21, -35 };
            //double[] plist3 = new double[] { 10, 3, 5, 10, 2 };
            //double[] plist4 = new double[] { -100, 100, 5, 10, 10, 400 };

            //canvas2.Visibility = Visibility.Hidden;
            //canvas5.Visibility = Visibility.Hidden;
            //canvas3.Visibility = Visibility.Hidden;
            //canvas4.Visibility = Visibility.Hidden;
            //p.plot2D(plist3, 2);
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            pr.terminate();
        }
    }
}

            