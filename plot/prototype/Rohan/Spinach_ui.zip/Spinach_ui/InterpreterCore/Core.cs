////////////////////////////////////////////////////////////////////////
// Core.cs: Executive for core processing of the SPINACH code.
// 
// version: 1.0
// Description: part of the interpreter example for the visitor design
//  pattern.
// Language:    C++/CLI, Visual Studio 2008 .Net Framework 3.5             
// Platform:    Dell Inspiron 1525, Windows Vista Business, SP 1       
// Application: Pr#2, CSE 784, Spring 2009                              
// Authors:     Rajika Tandon (ratandon@syr.edu)
//              Sushma Thimmappa (skyasara@syr.edu)
//              Rucha Bapat (rmbapat@syr.edu)            
// Source:      Phil Pratt-Szeliga (pcpratts@syr.edu)
////////////////////////////////////////////////////////////////////////
/*
 * Module Operations
 * ================= 
 * This file provides APIs to be used by other teams for communicating with 
 * the core. It provides a setAST() function which receives the Abstract Syntax 
 * Tree. Using this tree, we execute the entire code and perform semantic analysis
 * as well.
 * 
 * We also send the code execution results and errors to the User Interface using 
 * sendres() and result().
 * 
 * Public Interface
 * ================
 * Core core = new Core();  
 *                       // will create an instance of this class and allocate memory
 * 
 */
/*
 * Build Process
 * =============
 * Required Files:
 *   Front End Dlls
 * 
 * Maintenance History
 * ===================
 * ver 1.0 : 10 Nov 09
 *   - first release
 * 
 */

using System;
using System.Collections.Generic;
using System.Collections;
using System.Threading;

namespace Spinach
{
    public class Core 
    {
        InterpreterVisitor interp_visitor;
        
       // PrintVisitor print_visitor=new PrintVisitor(this);
        public delegate void errorcoremsg(int code, string errormsg);
        public event errorcoremsg errorcore_;

        public delegate void resultcore(string coremsg);
        public event resultcore rescore_;

        public delegate void compute(string coremsg);
        public event compute compute_;

        public delegate void executeParallel(string body, string data, int start, int stop, string range);
        public event executeParallel parallelcore_;

        public delegate void getResults(List<string> results);
        public event getResults parallelresult_;

        private int flag = -1;
        private int totalLines = 0;
        private int Visited = 0;
        private int compute_click = -1;
        List<Thread> threads = new List<Thread>();
        SwarmMemory smem;

        public int getComputeClick()
        {
            return compute_click;
        }
        public void sendres(int code, string errormsg)
        {
            if (errorcore_ != null)
            {
                if (flag == -1)
                {
                    errorcore_(code, errormsg);
                    flag = 1;
                }
                
            }

        }

        public void compute_clicked()
        {
            compute_click = 1;
        }


        public void getParallelResult(List<string> results)
        {
            if (parallelresult_ != null)
                parallelresult_(results);
        }
        public void execParallel(string body, string data, int start, int stop, string range)
        {
            if (parallelcore_ != null)
                parallelcore_(body, data, start, stop, range);
        }

        public void result(string coremsg)
        {
            if (rescore_ != null)
                rescore_(coremsg);
        }

                
        public void setSwarmObject(SwarmMemory sm)
        {
            smem = sm;
            interp_visitor.setSwarmObject(sm);
        }

        public void regToSwarm()
        {
            smem.parallelcore_ += new SwarmMemory.executeParallel(ParallelCore);
        }

        public void ParallelCore(string data, string body, int start, int stop, string range)
        {
            executor temp = new executor();
            temp.setSMObject(smem);
            temp.setCoreStart(data, body, start, stop, range);
            Thread t = new Thread(new ThreadStart(temp.doParallel));
            threads.Add(t);
            t.IsBackground = true;
            t.Start();
            /*temp.clearMap();
            temp.pstart = start;
            temp.pstop = stop;
            temp.pdata = data;
            temp.pbody = body;
            temp.prange = range;
            temp.setSwarm();
            temp.setFE(FE);
            temp.setSwarmObject(smem);
            Thread t = new Thread(new ThreadStart(temp.convertParallel));
            t.IsBackground = true;
            t.Start();*/
        }
        public void doParallel()
        {
            interp_visitor.convertParallel();
        }
        public void setValues(string data, string body, int start, int stop, string range)
        {
            interp_visitor.setBody(body);
            interp_visitor.setData(data);
            interp_visitor.setStart(start);
            interp_visitor.setStop(stop);
            interp_visitor.setRange(range);
            interp_visitor.setSwarm();
            interp_visitor.setSwarmObject(smem);
            interp_visitor.convertParallel();
        }

        public void clearThreads()
        {
            for (int i = 0; i < threads.Count; i++)
            {
                if(threads[i].IsAlive)
                threads[i].Abort();
            }
        }
        public void setSwarm()
        {
            interp_visitor.setSwarm();
        }

        public void setFrontEnd(exec FrontEnd)
        {
            interp_visitor.setFE(FrontEnd);
        }
        //List<Element> elements;
        public Core()
        {
             interp_visitor=new InterpreterVisitor();
             interp_visitor.errorcore_ += new InterpreterVisitor.errorcoremsg(sendres);
             interp_visitor.rescore_ += new InterpreterVisitor.resultcore(result);
             //interp_visitor.compute_ += new InterpreterVisitor.computeClick(setClick);
             
             //interp_visitor.setFE(FE);
        }

        public void setClick(int tempclick)
        {
            compute_click = tempclick;
        }

        public void setCompute(int click)
        {
            compute_click = click;
        }

        public void setPlotObject(PlotReceiver plotObj)
        {
            interp_visitor.setPlotObj(plotObj);
        }
        public void setAST(List<Element> elements)
        {
            //  element = ele;
            if (elements != null)
            {
                if (Visited != 1)
                {
                    totalLines = elements.Count;
                    Visited = 1;
                }
                for (int i = 0; i < elements.Count && flag != 1; i++)
                {
                    Element curr = elements[i];
                    // curr.Accept(print_visitor);
                    curr.Accept(interp_visitor);
                }

                if (totalLines == elements.Count && flag != 1 && compute_click == 1)
                {
                    smem.clearMasterBackup(true);
                    compute_click = -1;
                }
                if(compute_click ==0)
                    compute_click = -1;
            }
        }

        public void clearVarMap()
        {
            interp_visitor.clearMap();
            Visited = 0;
            flag = -1;
            //compute_click = -1;

        }


        }

}
