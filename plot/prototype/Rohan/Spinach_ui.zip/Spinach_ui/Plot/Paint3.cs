﻿////////////////////////////////////////////////////////////////////////
// Paint.cs - contains Paint class which generates points and returns
//            Canvas object depending on the properties and data given to
//            it.
// version: 1.0
// 
// author: Mahesh Uma Gudladona (ugudlado@syr.edu) & Rushabh Ravindra Gandhi (rugandhi@syr.edu)
// language: C#
////////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Media.Media3D;
using System.Collections;

namespace Spinach
{
    // Paints the canvas
    public class Paint
    {   //Private data members
        private int numPanes;
        private int spanX,spanY;
        private double factx, facty;
        private Point origin;
        private Canvas activeCanvas;
        private Canvas smallCanvas;
        private Viewport3D mainViewport;
        private List<Point> pointslist;
        private List<Point3D>pointslist3D;
        private List<Color>colorlist;
        private List<double> userdefcamdet;
        private List<double> default_valus;
        public PlotManager pm;
        private int mode;
        private string xtitle;
        private string ytitle;
        private string ztitle;
        private string plottitle;
        private Hashtable delaunaypoints = new Hashtable();
        private double actcanheight;
        private double actcanwidth;

        public delegate void PlotError(int code, string message);
        public event PlotError error;

        public void OnError(int code, string message)
        {
            if (error != null)
                error(code, message);

        } 

        //Properties
        #region Properties    
        public string Xtitle
        {
            get { return xtitle; }
            set { xtitle = value; }
        }

        public PlotManager pmanager
        {
            get { return pm; }
            set { pm = value; }

        }
        public string Ytitle
        {
            get { return ytitle; }
            set { ytitle = value; }
        }

        public string Ztitle
        {
            get { return ztitle; }
            set { ztitle = value; }
        }

        public string Plottitle
        {
            get { return plottitle; }
            set { plottitle = value; }
        }
            
        //Number of Panes
        public int NumberPanes  
        {           
            get { return numPanes; }
            set { numPanes = value; }
        }

        //Origin of Plot
        public Point Origin 
        {
            get { return origin; }
            set { origin = value; }
        }

        //Active Canvas
        public Canvas ActiveCanvas
        {
            get { return activeCanvas; }
            set { activeCanvas = value; }
        }

        //X-Factor
        public double X_Fact
        {
            get{return factx;}
            set { factx = value; }
        }

        //Y-Factor
        public double Y_Fact
        {
            get { return facty; }
            set { facty = value; }
        }

        //Scale Mode
        public int Mode
        {
            get { return mode; }
            set { mode = value; }
        }

        //Active viewport Rohan
        public Viewport3D Mainviewport
        {
            get { return mainViewport; }
            set { mainViewport = value; }
        }

        #endregion

        #region Methods
        //Methods

        //Paint Constructor
        public Paint()
        {
            numPanes = 1;
            spanX = 30;
            spanY = 30;
            actcanheight = 800;
            actcanwidth = 800;
            activeCanvas = new Canvas();

            activeCanvas.Width = actcanwidth;
            activeCanvas.Height = actcanheight;
            
            mainViewport = new Viewport3D();
            userdefcamdet = new List<double>();
            default_valus = new List<double>();
            mainViewport.Height = actcanheight;
            mainViewport.Width = actcanwidth;
            mode = 1;
            factx = 1;
            facty = 1;
            Xtitle = "X-Axis";
            Ytitle = "Y-Axis";
            Plottitle = "sample plot";
            pm = new PlotManager(this);
            pm.error += new PlotManager.PlotError(OnError);
        }

        //Reset method
        public void reset()
        {
            numPanes = 1;
            spanX = 30;
            spanY = 30;      
            activeCanvas = new Canvas();
            activeCanvas.Width = actcanwidth;
            activeCanvas.Height = actcanheight;
            mainViewport = new Viewport3D();
            mainViewport.Height = actcanheight;
            mainViewport.Width = actcanwidth;
            mode = 1;
            factx = 1;
            facty = 1;
            pm = new PlotManager(this);
        }


        //Method for setting Xaxis Title
        public void setXaxisTitle(string title)
        {
            Point xpoint = new Point();
            double x = (activeCanvas.Width - Origin.X) / 2;
            xpoint.X = x + Origin.X;
            xpoint.Y = Origin.Y + 5;
            setText(title, xpoint);
            
        }
        //Method for setting Yaxis Title
        public void setYaxisTitle(string title)
        {
            Point ypoint = new Point();
            double y = Origin.Y / 2;
            ypoint.X = Origin.X - 35;
            ypoint.Y = y;
            setText(title, ypoint);

        }

        ////Method for setting zaxis Title
        //private void setzaxisTitle(string title)
        //{
        //    Point zpoint = new Point();
        //    double z = activeCanvas.Width / 2;
        //    ypoint.X = origin.X - 35;
        //    ypoint.Y = y;
        //    setText(title, ypoint);

        //}

        //Method for setting Plot Title
        public void setPlotTitle(string title)
        {
            Point point = new Point();
            double x = (activeCanvas.Width - Origin.X);
            x = 0.5 * x;
            point.X = x + Origin.X;
            double y = activeCanvas.Height - Origin.Y;
            point.Y = 0.2 * y;
            setText(title, point);

        }


                //Method for setting axes        

        private string pointToText(Point point)
        {
            string temp = Math.Round(((point.X - origin.X) / spanX),2).ToString() + "," + Math.Round(((origin.Y - point.Y) / spanY),2).ToString();
            return temp;
        }

        //Helper method for setting text at specified point on Pane
        private void setText(string pointText,Point point)
        {
            TextBlock txt = new TextBlock();
            txt.Text = pointText;
            Canvas.SetLeft(txt, point.X );
            Canvas.SetTop(txt, point.Y);
            activeCanvas.Children.Add(txt);
        }

        //Helper method for transforming values to 2D points
        private List<Point> transformValuesToPoints(double[] pvalues)
        {
            List<Point> templist = new List<Point>();
            for (int i = 0; i < pvalues.GetLength(0); i++)
            {
                Point temp = new Point(i, pvalues[i]);
                templist.Add(temp);
            }
            return templist;
        }

        //Plot method for displaying value into 2D points in a line graph
        public void plot2D(double[] plist)
        {
            activeCanvas = new Canvas();
            activeCanvas.Width = actcanwidth;
            activeCanvas.Height = actcanheight;
            try
            {
                switch (mode)
                {
                    case 1: pointslist = transformValuesToPoints(plist);
                        plotPoints(pointslist);
                        break;
                    case 2:
                        pointslist = transformValuesToPoints(plist);
                        plotLogPoints();
                        break;
                }
                pm.Convert_to_Image(activeCanvas, -1);
                subplot2D(plist, -1);
                activeCanvas = new Canvas();
                activeCanvas.Width = actcanwidth;
                activeCanvas.Height = actcanheight;
            }
            catch (Exception e)
            {
                OnError(122, e.Message);
            }
        }                


        public void plotPoints(List<Point> pointslist)
        {                        
            setAxes();
            setXaxisTitle(Xtitle);
            setYaxisTitle(Ytitle);
            setPlotTitle(Plottitle);
            GeometryGroup s = new GeometryGroup();
            PathGeometry pg = new PathGeometry();
            PathFigureCollection pfc = new PathFigureCollection();
            PathFigure pf = new PathFigure();
            PathSegmentCollection psc = new PathSegmentCollection();
            Point stpoint = pointslist[0];            
            stpoint.X = Math.Round(origin.X + spanX * stpoint.X,2);
            stpoint.Y = Math.Round(origin.Y - spanY * stpoint.Y,2);
            pf.StartPoint = stpoint;
            EllipseGeometry elg = new EllipseGeometry(stpoint, 2, 2);
            s.Children.Add(elg);
            string pointText = pointToText(stpoint);
            setText(pointText,stpoint);
            for (int i = 1; i < pointslist.Count; i++)
            {
                Point point = pointslist[i];
                point.X = Math.Round(origin.X + spanX * point.X,2);
                point.Y = Math.Round(origin.Y - spanY * point.Y,2);
                LineSegment ls = new LineSegment(point, true);
                elg = new EllipseGeometry(point, 2, 2);
                setText(pointToText(point),point);
                s.Children.Add(elg);
                psc.Add(ls);
            }
            pf.Segments = psc;
            pfc.Add(pf);           
            pg.Figures = pfc;
            Path p = new Path();
            Path p1 = new Path();
            p.Data = pg;            
            p.Stroke = Brushes.Green;
            p1.Data = s;
            p1.Fill = Brushes.Blue;            
            activeCanvas.Children.Add(p);
            activeCanvas.Children.Add(p1);
            activeCanvas.ClipToBounds = true;            
        }

        //Method to plot depending on the given pane number
        public void subplot2D(double[] plist,int panenum)
         {
            if (panenum != -1){
            activeCanvas = new Canvas();
            activeCanvas.Tag = "subplot2D";
            activeCanvas.Width = actcanwidth;
            activeCanvas.Height = actcanheight;
            adjustPaneSize(panenum);
            pointslist = transformValuesToPoints(plist);
            if (mode == 1)
                plotPoints(pointslist);
            else
                plotLogPoints();
            pm.Convert_to_Image(activeCanvas, panenum);
            }
            else{
                activeCanvas = new Canvas();
                
                activeCanvas.Width = actcanwidth;
                activeCanvas.Height = actcanheight;
                adjustPaneSize(4);
                pointslist = transformValuesToPoints(plist);
                if (mode == 1)
                    plotPoints(pointslist);
                else
                    plotLogPoints();
                smallCanvas = activeCanvas;
            }                           
        }

        public Canvas resubplot2D()
        {            
            
            return smallCanvas;
        }


        //Helper method which adjusts the pane size depending on the number of panes property
        private void adjustPaneSize(int panenum)
        {
            int wfactor=1;
            int hfactor = 1;
            if (panenum > NumberPanes)
            {
                switch (panenum - NumberPanes)
                {                    
                    case 1:                             
                    case 2:
                    case 3:
                        NumberPanes = 4;
                        break;
                    default:
                        NumberPanes = 1;
                        break;
                }
                //NumberPanes *= 2;
                //break;
            }
            switch (NumberPanes)
            {
                case 2:
                    wfactor = 2;
                    break;
                case 4:
                    wfactor = 2;
                    hfactor = 2;
                    break;
                default:
                    wfactor = 1;
                    hfactor = 1;
                    break;
            }
            activeCanvas.Width = actcanwidth / wfactor;
            activeCanvas.Height = actcanheight / hfactor;
        }
   
        #endregion
        
        #region Rushabh
        // made by rushabh
        private Point MinPoint()
        {
            Point MinXY = pointslist[0];
            for (int i = 1; i < pointslist.Count; i++)
            {
                if (pointslist[i].X < MinXY.X)
                    MinXY.X = pointslist[i].X;
                if (pointslist[i].Y < MinXY.Y)
                    MinXY.Y = pointslist[i].Y;
            }
            return (MinXY);
        }

        // made by rushabh
        private Point MaxPoint()
        {
            Point MaxXY = pointslist[0];
            for (int i = 1; i < pointslist.Count; i++)
            {
                if (pointslist[i].X > MaxXY.X)
                    MaxXY.X = pointslist[i].X;
                if (pointslist[i].Y > MaxXY.Y)
                    MaxXY.Y = pointslist[i].Y;
            }
            return (MaxXY);
        }

        // made by rushabh
        private void CalOrigin()
        {
            Point min = MinPoint();
            Point max = MaxPoint();
            double orix = ((max.X >= 0 && min.X <= 0) || (max.X <= 0 && min.X >= 0)) ? Math.Abs(min.X) + 1 : (min.X > 0) ? 1 : Math.Abs(min.X) + 1;
            double oriy = ((max.Y >= 0 && min.Y <= 0) || (max.Y <= 0 && min.Y >= 0)) ? Math.Abs(min.Y) + 1 : (min.Y > 0) ? 1 : Math.Abs(min.Y) + 1;
            Origin = new Point(orix * spanX + 20, activeCanvas.Height - ((oriy * spanY)) - 20);
        }

        // made by rushabh
        private void setScale()
        {
            Point minPt = MinPoint();
            Point maxPt = MaxPoint();
            double Xlen = ((maxPt.X >= 0 && minPt.X <= 0) || (maxPt.X <= 0 && minPt.X >= 0)) ? (Math.Abs(maxPt.X) + Math.Abs(minPt.X)) + 2 : (minPt.X > 0) ? maxPt.X + 2 : Math.Abs(minPt.X) + 2;
            double Ylen = ((maxPt.Y >= 0 && minPt.Y <= 0) || (maxPt.Y <= 0 && minPt.Y >= 0)) ? (Math.Abs(maxPt.Y) + Math.Abs(minPt.Y)) + 2 : (minPt.Y > 0) ? maxPt.Y + 2 : Math.Abs(minPt.Y) + 2;
            spanX = (int)((activeCanvas.Width - 40) / Xlen / factx);
            spanY = (int)((activeCanvas.Height - 40) / Ylen / facty);
            spanX = spanX == 0 ? 1 : spanX;
            spanY = spanY == 0 ? 1 : spanY;
        }

        // changed by rushabh
        private void setAxes()
        {
            EllipseGeometry elg;
            setScale();
            CalOrigin();
            double xstep = spanX;
            double ystep = -spanY;
            drawAxis();
            Path path1 = new Path();
            path1.Fill = Brushes.Black;
            GeometryGroup gg = new GeometryGroup();

            int jx, jy, xtext, ytext;
            int xpart = (int)(activeCanvas.Width - 40) / spanX;
            int ypart = (int)(activeCanvas.Height - 40) / spanY;
            //xtext = jx = (xpart < 25) ? 1 : (xpart < 50) ? 2 : (xpart < 100) ? 5 : (xpart < 200) ? 10 : 50;
            //ytext = jy = (ypart < 25) ? 1 : (ypart < 50) ? 2 : (ypart < 100) ? 5 : (ypart < 200) ? 10 : 50;
            xtext = jx = Math.Ceiling((double)xpart / 10) == 0 ? 1 : (int)Math.Ceiling((double)xpart / 10);
            ytext = jy = Math.Ceiling((double)ypart / 10) == 0 ? 1 : (int)Math.Ceiling((double)ypart / 10);
            xstep *= jx;
            ystep *= jy;
            int xincre = (int)xstep;
            int yincre = (int)ystep;

            setText(Convert.ToString(0), new Point(origin.X - 5, origin.Y));
            gg.Children.Add(new EllipseGeometry(origin, 2, 2));
            while ((origin.X + xstep < activeCanvas.Width - 40) || (origin.Y + ystep > 20) || (origin.X - xstep > 20) || (origin.Y - ystep < activeCanvas.Height - 40))
            {
                Point px = (origin.X + xstep < activeCanvas.Width - 40) ? new Point(origin.X + xstep, origin.Y) : new Point(activeCanvas.Width + 10, activeCanvas.Height + 10);
                Point py = (origin.Y + ystep > 20) ? new Point(origin.X, origin.Y + ystep) : new Point(activeCanvas.Width + 10, activeCanvas.Height + 10);
                Point pnx = (origin.X - xstep > 20) ? new Point(origin.X - xstep, origin.Y) : new Point(activeCanvas.Width + 10, activeCanvas.Height + 10);
                Point pny = (origin.Y - ystep < activeCanvas.Height - 40) ? new Point(origin.X, origin.Y - ystep) : new Point(activeCanvas.Width + 10, activeCanvas.Height + 10);

                elg = new EllipseGeometry(px, 2, 2);
                setText(Convert.ToString(xtext), new Point(origin.X + xstep, origin.Y));
                gg.Children.Add(elg);

                elg = new EllipseGeometry(py, 2, 2);
                setText(Convert.ToString(ytext), new Point(origin.X - 10, origin.Y + ystep));
                gg.Children.Add(elg);

                elg = new EllipseGeometry(pnx, 2, 2);
                setText(Convert.ToString(-xtext), new Point(origin.X - xstep, origin.Y));
                gg.Children.Add(elg);

                elg = new EllipseGeometry(pny, 2, 2);
                setText(Convert.ToString(-ytext), new Point(origin.X - 10, origin.Y - ystep));
                gg.Children.Add(elg);

                xstep += xincre;
                ystep += yincre;
                xtext += jx;
                ytext += jy;
            }
            path1.Data = gg;
            activeCanvas.Children.Add(path1);
        }

        //changed by Rushabh
        private void setlogAxes()
        {
            EllipseGeometry elg;
            setLogScale();
            CalLogOrigin();
            double xstep = spanX;
            double ystep = -spanY;
            
            Path path1 = new Path();
            path1.Fill = Brushes.Black;
            GeometryGroup gg = new GeometryGroup();
            drawAxis();
            int jx, jy, xtext, ytext;
            int xpart = (int)(activeCanvas.Width - 20) / spanX;
            int ypart = (int)(activeCanvas.Height - 20) / spanY;
            xtext = jx = (xpart < 25) ? 1 : (xpart < 50) ? 2 : (xpart < 100) ? 5 : (xpart < 200) ? 10 : 50;
            ytext = 10;
            jy = 10;
            xstep *= jx;
            int xincre = (int)xstep;
            int yincre = (int)ystep;

            setText(Convert.ToString(0), new Point(origin.X - 5, origin.Y));
            gg.Children.Add(new EllipseGeometry(origin, 2, 2));
            while ((origin.X + xstep < activeCanvas.Width - 40) || (origin.Y + ystep > 20) || (origin.X - xstep > 20) || (origin.Y - ystep < activeCanvas.Height - 40))
            {
                Point px = (origin.X + xstep < activeCanvas.Width - 40) ? new Point(origin.X + xstep, origin.Y) : new Point(activeCanvas.Width + 10, activeCanvas.Height + 10);
                Point py = (origin.Y + ystep > 20) ? new Point(origin.X, origin.Y + ystep) : new Point(activeCanvas.Width + 10, activeCanvas.Height + 10);
                Point pnx = (origin.X - xstep > 20) ? new Point(origin.X - xstep, origin.Y) : new Point(activeCanvas.Width + 10, activeCanvas.Height + 10);
                Point pny = (origin.Y - ystep < activeCanvas.Height - 40) ? new Point(origin.X, origin.Y - ystep) : new Point(activeCanvas.Width + 10, activeCanvas.Height + 10);

                elg = new EllipseGeometry(px, 2, 2);
                setText(Convert.ToString(xtext), new Point(origin.X + xstep, origin.Y));
                gg.Children.Add(elg);

                elg = new EllipseGeometry(py, 2, 2);
                setText(Convert.ToString(ytext), new Point(origin.X - 10, origin.Y + ystep));
                gg.Children.Add(elg);

                elg = new EllipseGeometry(pnx, 2, 2);
                setText(Convert.ToString(-xtext), new Point(origin.X - xstep, origin.Y));
                gg.Children.Add(elg);

                elg = new EllipseGeometry(pny, 2, 2);
                setText(Convert.ToString(-1 / ytext), new Point(origin.X - 10, origin.Y - ystep));
                gg.Children.Add(elg);

                xstep += xincre;
                ystep += yincre;
                xtext += jx;
                ytext *= jy;
            }
            path1.Data = gg;
            activeCanvas.Children.Add(path1);
        }

        private void drawAxis()
        {
            Line l = new Line();
            l.X1 = origin.X;
            l.Y1 = origin.Y;
            l.X2 = activeCanvas.Width - 20;
            l.Y2 = origin.Y;
            l.Stroke = Brushes.Black;
            Line ly = new Line();
            ly.X1 = origin.X;
            ly.Y1 = (origin.Y - activeCanvas.Height) < 20 ? 20 : origin.Y - activeCanvas.Height;
            ly.X2 = origin.X;
            ly.Y2 = origin.Y;
            ly.Stroke = Brushes.Black;
            Line l1 = new Line();
            l1.X1 = origin.X;
            l1.Y1 = origin.Y;
            l1.X2 = 20;
            l1.Y2 = origin.Y;
            l1.Stroke = Brushes.Black;
            Line ly1 = new Line();
            ly1.X1 = origin.X;
            ly1.Y1 = activeCanvas.Height - 20;
            ly1.X2 = origin.X;
            ly1.Y2 = origin.Y;
            ly1.Stroke = Brushes.Black;
            activeCanvas.Children.Add(ly);
            activeCanvas.Children.Add(l);
            activeCanvas.Children.Add(ly1);
            activeCanvas.Children.Add(l1);
        }

        //changed by rushabh
        private void plotLogPoints()
        {
            setlogAxes();
            setXaxisTitle(Xtitle);
            setYaxisTitle(Ytitle);
            setPlotTitle(Plottitle);
            GeometryGroup s = new GeometryGroup();
            PathGeometry pg = new PathGeometry();
            PathFigureCollection pfc = new PathFigureCollection();
            PathFigure pf = new PathFigure();
            PathSegmentCollection psc = new PathSegmentCollection();
            Point stpoint = pointslist[0];
            Point pt = new Point();
            //stpoint.X = Math.Round(origin.X + spanX * stpoint.X, 2);
            //stpoint.Y = Math.Round(origin.Y - spanY * stpoint.Y, 2);
            pt.X = Math.Round(origin.X + spanX * stpoint.X, 2);
            pt.Y = Math.Round(origin.Y - spanY * Math.Log10(stpoint.Y), 2);

            pf.StartPoint = pt;
            EllipseGeometry elg = new EllipseGeometry(pt, 2, 2);
            s.Children.Add(elg);
            setText(stpoint.X.ToString() + "," + stpoint.Y.ToString(), pt);
            for (int i = 1; i < pointslist.Count; i++)
            {
                Point point = pointslist[i];
                point.X = Math.Round(point.X, 2);
                point.Y = Math.Round(point.Y, 2);
                pt.X = Math.Round(origin.X + spanX * point.X, 2);
                pt.Y = Math.Round(origin.Y - spanY * Math.Log10(point.Y), 2);
                LineSegment ls = new LineSegment(pt, true);
                elg = new EllipseGeometry(pt, 2, 2);
                setText(point.X.ToString() + "," + point.Y.ToString(), pt);
                s.Children.Add(elg);
                psc.Add(ls);
            }
            pf.Segments = psc;
            pfc.Add(pf);
            pg.Figures = pfc;
            Path p = new Path();
            Path p1 = new Path();
            p.Data = pg;
            p.Stroke = Brushes.Green;
            p1.Data = s;
            p1.Fill = Brushes.Blue;
            activeCanvas.Children.Add(p);
            activeCanvas.Children.Add(p1);
            activeCanvas.ClipToBounds = true;
        }

        //made by rushabh
        private void CalLogOrigin()
        {
            Point min = MinPoint();
            Point max = MaxPoint();
            double orix = ((max.X >= 0 && min.X <= 0) || (max.X <= 0 && min.X >= 0)) ? Math.Abs(min.X) + 1 : (min.X > 0) ? 1 : Math.Abs(min.X) + 1;
            double oriy = ((Math.Log10(max.Y) >= 0 && Math.Log10(min.Y) <= 0) || (Math.Log10(max.Y) <= 0 && Math.Log10(min.Y) >= 0)) ? Math.Abs(Math.Log10(min.Y)) : (Math.Log10(min.Y) > 0) ? 0.1 : Math.Abs(Math.Log10(min.Y));
            Origin = new Point(orix * spanX + 20, activeCanvas.Height - ((oriy * spanY)) - 20);
        }

         // made by rushabh
        private void setLogScale()
        {
            Point minPt = MinPoint();
            Point maxPt = MaxPoint();
            double Xlen = ((maxPt.X >= 0 && minPt.X <= 0) || (maxPt.X <= 0 && minPt.X >= 0)) ? (Math.Abs(maxPt.X) + Math.Abs(minPt.X)) + 2 : (minPt.X > 0) ? maxPt.X + 2 : Math.Abs(minPt.X) + 2;
            double Ylen = Math.Ceiling(((Math.Log10(maxPt.Y) >= 0 && Math.Log10(minPt.Y) <= 0) || (Math.Log10(maxPt.Y) <= 0 && Math.Log10(minPt.Y) >= 0)) ? (Math.Abs(Math.Log10(maxPt.Y)) + Math.Abs(Math.Log10(minPt.Y))) : ((Math.Log10(minPt.Y)) > 0) ? Math.Log10(maxPt.Y) : Math.Abs(Math.Log10(minPt.Y)));
            Ylen += Ylen / 10;
            spanX = (int)((activeCanvas.Width - 40) / Xlen / factx);
            spanY = (int)((activeCanvas.Height - 40) / Ylen / facty);
        }
 
 

        #endregion

        #region 3D-Rushabh

        private Point3D MinPoint3D()
        {
            Point3D Min = pointslist3D[0];
            for (int i = 1; i < pointslist3D.Count; i++)
            {
                if (pointslist3D[i].X < Min.X)
                    Min.X = pointslist3D[i].X;
                if (pointslist3D[i].Y < Min.Y)
                    Min.Y = pointslist3D[i].Y;
                if (pointslist3D[i].Z < Min.Z)
                    Min.Z = pointslist3D[i].Z;
            }
            return (Min);
        }

        private Point3D MaxPoint3D()
        {
            Point3D Max = pointslist3D[0];
            for (int i = 1; i < pointslist3D.Count; i++)
            {
                if (pointslist3D[i].X > Max.X)
                    Max.X = pointslist3D[i].X;
                if (pointslist3D[i].Y > Max.Y)
                    Max.Y = pointslist3D[i].Y;
                if (pointslist3D[i].Z > Max.Z)
                    Max.Z = pointslist3D[i].Z;
            }
            return (Max);
        }

        public void chagecam(List<double> obj)
        {
            userdefcamdet = obj;
        }

        private double calAngle(Point3D pt)
        {
            double maxz = MaxPoint3D().Z;
            double angle = pt.Z / maxz * 360;
            angle = angle*3.14/180; // converting into radians
            return angle;
        }

        public void Vector3D_sub_new(double[,] data, int paneno)
        {
            pointslist3D = transformValuesTo3DPoints(data);
            pointslist = new List<Point>();
            for (int i = 0; i < pointslist3D.Count; i++)
            {
                pointslist.Add(new Point(pointslist3D[i].X, pointslist3D[i].Y));
            }

            activeCanvas = new Canvas();
            activeCanvas.Width = actcanwidth/2;
            activeCanvas.Height = actcanheight/2;
            activeCanvas.Tag = "subplot2D";

            setAxes();
            setXaxisTitle(Xtitle);
            setYaxisTitle(Ytitle);
            setPlotTitle(Plottitle);
            
            for (int i = 0; i < pointslist3D.Count; i++)
                line(pointslist3D[i]);
            pm.Convert_to_Image(activeCanvas, paneno);
          }

        public void Vector3D_new(double[,] data)
        {
            pointslist3D = transformValuesTo3DPoints(data);
            pointslist = new List<Point>();
            for (int i = 0; i < pointslist3D.Count; i++)
            {
                pointslist.Add(new Point(pointslist3D[i].X, pointslist3D[i].Y));
            }

            activeCanvas = new Canvas();
            activeCanvas.Width = actcanwidth;
            activeCanvas.Height = actcanheight;
            activeCanvas.Tag = "plot2D";

            setAxes();
            setXaxisTitle(Xtitle);
            setYaxisTitle(Ytitle);
            setPlotTitle(Plottitle);

            for (int i = 0; i < pointslist3D.Count; i++)
                line(pointslist3D[i]);
            pm.Convert_to_Image(activeCanvas, -1);

            activeCanvas = new Canvas();
            adjustPaneSize(4);

            setAxes();
            setXaxisTitle(Xtitle);
            setYaxisTitle(Ytitle);
            setPlotTitle(Plottitle);

            for (int i = 0; i < pointslist3D.Count; i++)
                line(pointslist3D[i]);

            smallCanvas = activeCanvas;
            activeCanvas = new Canvas();
            activeCanvas.Width = actcanwidth;
            activeCanvas.Height = actcanheight;
        }

        private void line(Point3D pt)
        {
            Line myLine = new Line();
            double length = 0.3;
            myLine.Stroke = System.Windows.Media.Brushes.LightSteelBlue;
            myLine.X1 = Math.Round(origin.X + spanX * pt.X,2);
            myLine.Y1 = Math.Round(origin.Y - spanY * pt.Y,2);
            Point point = new Point(myLine.X1,myLine.Y1);
            string pointText = pointToText(point);
            double tetha = calAngle(pt);
            //string angle = Math.Round(tetha * 180 / 3.14, 2).ToString(); // print in degrees
            //setText(angle, point);
            myLine.X2 = Math.Round(origin.X + spanX * (pt.X + length * (3 * Math.Cos(tetha))), 2);
            myLine.Y2 = Math.Round(origin.Y - spanY * (pt.Y + length *(3 * Math.Sin(tetha))), 2);
            Point point2 = new Point(myLine.X2, myLine.Y2);
            //pointText = pointToText(point2);
            //setText(pointText, point2);
            myLine.HorizontalAlignment = HorizontalAlignment.Left;
            myLine.VerticalAlignment = VerticalAlignment.Center;
            myLine.StrokeThickness = 2;
            activeCanvas.Children.Add(myLine);
            arrow(point, point2, tetha * 180 / 3.14);
            activeCanvas.ClipToBounds = true;
        }

        private void arrow(Point pt1, Point pt2,double angle)
        {
            double height = 16.0;
            double width = 2.0;
            Point[] tripoint = new Point[3];
            double slope = (pt2.Y - pt1.Y) / (pt2.X - pt1.X);
            if ((angle > 90 && angle <= 180) || (angle > 270 && angle <= 360))
                slope = -slope;
            if (pt2.X > pt1.X)
            {
                if (slope < 0)
                {
                    tripoint[0].X = Math.Round(pt2.X + Math.Sqrt(height) / Math.Sqrt((1 + Math.Pow(slope, 2))), 2);
                }
                else
                    tripoint[0].X = Math.Round(pt2.X - Math.Sqrt(height) / Math.Sqrt((1 + Math.Pow(slope, 2))), 2);
                tripoint[1].X = Math.Round(pt2.X + slope * Math.Sqrt(width) / Math.Sqrt(1 + Math.Pow(slope, 2)), 2);
                tripoint[2].X = Math.Round(pt2.X - slope * Math.Sqrt(width) / Math.Sqrt(1 + Math.Pow(slope, 2)), 2);
            }
            else
            {
                if (slope < 0)
                {
                    tripoint[0].X = Math.Round(pt2.X - Math.Sqrt(height) / Math.Sqrt((1 + Math.Pow(slope, 2))), 2);
                }
                else
                    tripoint[0].X = Math.Round(pt2.X + Math.Sqrt(height) / Math.Sqrt((1 + Math.Pow(slope, 2))), 2);
                tripoint[1].X = Math.Round(pt2.X - slope * Math.Sqrt(width) / Math.Sqrt(1 + Math.Pow(slope, 2)), 2);
                tripoint[2].X = Math.Round(pt2.X + slope * Math.Sqrt(width) / Math.Sqrt(1 + Math.Pow(slope, 2)), 2);
            }
            if (pt2.Y > pt1.Y)
            {
                if (slope > 0)
                {
                    tripoint[0].Y = Math.Round(pt2.Y + Math.Sqrt(height) * slope / Math.Sqrt((1 + Math.Pow(slope, 2))), 2);
                }
                else
                    tripoint[0].Y = Math.Round(pt2.Y - Math.Sqrt(height) * slope / Math.Sqrt((1 + Math.Pow(slope, 2))), 2);
                tripoint[1].Y = Math.Round(pt2.Y + Math.Sqrt(width) / Math.Sqrt(1 + Math.Pow(slope, 2)), 2);
                tripoint[2].Y = Math.Round(pt2.Y - Math.Sqrt(width) / Math.Sqrt(1 + Math.Pow(slope, 2)), 2);
            }
            else
            {
                if (slope > 0)
                {
                    tripoint[0].Y = Math.Round(pt2.Y - Math.Sqrt(height) * slope / Math.Sqrt((1 + Math.Pow(slope, 2))), 2);
                }
                else
                    tripoint[0].Y = Math.Round(pt2.Y + Math.Sqrt(height) * slope / Math.Sqrt((1 + Math.Pow(slope, 2))), 2);
                tripoint[1].Y = Math.Round(pt2.Y - Math.Sqrt(width) / Math.Sqrt(1 + Math.Pow(slope, 2)), 2);
                tripoint[2].Y = Math.Round(pt2.Y + Math.Sqrt(width) / Math.Sqrt(1 + Math.Pow(slope, 2)), 2);
            }

            Polygon myPolygon = new Polygon();
            for (int i = 0; i < 3; i++)
                myPolygon.Points.Add(tripoint[i]);
            myPolygon.Fill = Brushes.Blue;
            myPolygon.Stroke = Brushes.Black;
            myPolygon.StrokeThickness = 2;
            activeCanvas.Children.Add(myPolygon);
        }
        
        #endregion

        #region 3D-Mahesh
        //Helper method for transforming values to 3D points
        private List<Point3D> transformValuesTo3DPoints(double[,] pvalues)
        {
            List<Point3D> templist = new List<Point3D>();
            for (int i = 0; i < pvalues.GetLength(0); i++)
            {
                for (int j = 0; j < pvalues.GetLength(1); j++)
                {
                    Point3D temp = new Point3D(i + 1, j + 1, pvalues[i, j]);
                    templist.Add(temp);
                }
            }
            return templist;
        }

        public void subplot_3Dto2D(double[,] values, int panenum)
        {
            activeCanvas = new Canvas();
            adjustPaneSize(4);
            plot3D_2D(values);
            activeCanvas.Tag = "subplot2D";
            pm.Convert_to_Image(activeCanvas, panenum);
        }
        Canvas resubPlot3D()
        {
            return smallCanvas;
        }

        //Method to plot 3D data into 2D with z-index as color variation
        public void plot3DInto2D(double[,] values)
        {

            numPanes = 1;
            activeCanvas = new Canvas();
            activeCanvas.Width = actcanwidth;
            activeCanvas.Height = actcanheight;
            activeCanvas.Tag = "plot2D";
            plot3D_2D(values);
            pm.Convert_to_Image(activeCanvas, -1);
            activeCanvas = new Canvas();
            adjustPaneSize(4);
            plot3D_2D(values);
            smallCanvas = activeCanvas;
            activeCanvas = new Canvas();
            activeCanvas.Width = actcanwidth;
            activeCanvas.Height = actcanheight;

        }
        private void plot3D_2D(double[,] values)
        {
            pointslist3D = transformValuesTo3DPoints(values);
            List<Point3D> plist = pointslist3D;
            pointslist = new List<Point>();
            for (int i = 0; i < plist.Count; i++)
            {
                pointslist.Add(new Point(plist[i].X, plist[i].Y));
            }
            setAxes();
            setColorBand();
            printColorBand();
            GeometryGroup s = new GeometryGroup();
            for (int i = 0; i < plist.Count; i++)
            {
                Point point = new Point(plist[i].X, plist[i].Y);
                point.X = origin.X + spanX * point.X;
                point.Y = origin.Y - spanY * point.Y;
                Ellipse el = new Ellipse();
                el.Height = 8;
                el.Width = 8;
                Canvas.SetLeft(el, point.X - 10);
                Canvas.SetTop(el, point.Y);
                Brush b = new SolidColorBrush(getColor(plist[i].Z));
                el.Fill = b;
                el.Stroke = b;
                activeCanvas.Children.Add(el);

            }
            activeCanvas.ClipToBounds = true;
        }

        void printColorBand()
        {
            int w = 30;
            int h = 5;
            for (int i = 0; i < colorlist.Count; i++)
            {
                Rectangle r = new Rectangle();
                r.Width = w;
                r.Height = h;
                Canvas.SetLeft(r, activeCanvas.Width - 75);
                Canvas.SetTop(r, 10 + i * r.Height);
                r.Fill = new SolidColorBrush(colorlist[i]);
                activeCanvas.Children.Add(r);
            }
            double max = MaxPoint3D().Z;
            double min = MinPoint3D().Z;
            double diff = Math.Abs(max - min);
            double s = getInterval(max, min);
            for (double i = min; i < max; i += s)
            {
                setText(i.ToString(), new Point(activeCanvas.Width - 35, h * colorlist.Count / diff * (max - i)));
            }
            setText(max.ToString(), new Point(activeCanvas.Width - 35, h));
        }

        double getInterval(double max, double min)
        {
            double inter;
            int diff = Convert.ToInt32(max - min);
            int i = 0;
            for (i = 0; diff % Math.Pow(10, i) != diff; i++) ;
            int j = 0;
            for (; diff % (Math.Pow(10, i) * j) != diff; j++) ;
            if (i == 1)
                inter = 5 * (j);
            else
                inter = (i - 1) * 10;
            inter = inter == 0 ? 1 : inter;
            return inter;
        }

        void setColorBand()
        {
            colorlist = new List<Color>();
            for (int i = 0; i < 10; i++)
            {
                Color temp = new Color();
                temp.ScR = 1.0F;
                temp.ScG = i * 0.1F;
                temp.ScB = 0;
                temp.ScA = 1;
                colorlist.Add(temp);
            }
            for (int i = 0; i < 10; i++)
            {
                Color temp = new Color();
                temp.ScR = 1 - 0.1F * i;
                temp.ScG = 1.0F;
                temp.ScB = 0;
                temp.ScA = 1;
                colorlist.Add(temp);
            }
            for (int i = 0; i < 10; i++)
            {
                Color temp = new Color();
                temp.ScR = 0;
                temp.ScG = 1.0F;
                temp.ScB = 0.1F * i;
                temp.ScA = 1;
                colorlist.Add(temp);
            }
            for (int i = 0; i <= 10; i++)
            {
                Color temp = new Color();
                temp.ScR = 0;
                temp.ScG = 1 - 0.1F * i;
                temp.ScB = 1.0F;
                temp.ScA = 1;
                colorlist.Add(temp);
            }
        }

        Color getColor(double zindex)
        {
            double max = MaxPoint3D().Z;
            double min = MinPoint3D().Z;
            double diff = Math.Abs(max - min);
            double partdiff = diff / 10;
            Color tempColor = new Color();
            int i;
            if (diff == 0)
                diff = 1;
            i = Convert.ToInt32((colorlist.Count / diff) * (max - zindex));
            if (i < 0)
                i = 0;
            else if (i > colorlist.Count - 1)
                i = colorlist.Count - 1;
            tempColor = colorlist[i];
            return tempColor;
        }
        #endregion

        #region 3D-Rohan
        //Add Camera Details
        private PerspectiveCamera Camera_Details(double point)
        {
           // default_valus.Clear();
            PerspectiveCamera camera = new PerspectiveCamera();
            if (userdefcamdet.Count != 0)
            {
               // camera.FarPlaneDistance = userdefcamdet[6];
                camera.LookDirection = new Vector3D(userdefcamdet[3], userdefcamdet[4], userdefcamdet[5]);
               // camera.UpDirection = new Vector3D(userdefcamdet[7], userdefcamdet[8], userdefcamdet[9]);
                camera.NearPlaneDistance = userdefcamdet[10];
                camera.Position = new Point3D(userdefcamdet[0], userdefcamdet[1], userdefcamdet[2]);
                camera.FieldOfView = userdefcamdet[11];
            }
            else
            {
                //camera.FarPlaneDistance = 1000;

                camera.LookDirection = new Vector3D(0, 0, -1);
                //camera.UpDirection = new Vector3D(0, 3, 0);

                camera.NearPlaneDistance = 1.25;
                camera.Position = new Point3D(0, 0, point + 5);
                camera.FieldOfView = 45;

                default_valus.Add(0);
                default_valus.Add(0);
                default_valus.Add(point + 5);
                default_valus.Add(0);
                default_valus.Add(0);
                default_valus.Add(-1);
                default_valus.Add(1.25);
                default_valus.Add(45);

            }
            return camera;
        }




        //sets the properties for visual content for plot 3D
        private ModelVisual3D ModelVisual3D_Details(double point)
        {
            ModelVisual3D md = new ModelVisual3D();
            DirectionalLight d = new DirectionalLight();
            d.Color = Colors.White;
            d.Direction = new Vector3D(0, 0, point + 5);
            md.Content = d;
            return md;
        }

        //Convert 3d Points to Geometry points for Delauny Traingulation
        private List<Triangulator.Geometry.Point> Points3dtoPoints2d(Point3D[] points3d)
        {

            int index = 0;
            //Point[] points2d = new Point[points3d.Length];
            List<Triangulator.Geometry.Point> points2d = new List<Triangulator.Geometry.Point>();
            int count = 0;
            for (; index < points3d.Length; index++)
            {

                Triangulator.Geometry.Point gmpoint = new Triangulator.Geometry.Point(points3d[index].X, points3d[index].Y);
                points2d.Add(gmpoint);
                string s;
                s = gmpoint.X.ToString();
                s += gmpoint.Y.ToString();
                delaunaypoints[s] = points3d[index];
                count++;

            }
            return points2d;
        }

        //plot 3D 
        public void plot3D_Terrain(double[,] data)
        {
            default_valus.Clear();
            double maxpoint = max_point_3D(data);
            default_valus.Add(-1);
            mainViewport = new Viewport3D();
            this.mainViewport.Height = actcanheight;
            this.mainViewport.Width = actcanwidth;

            mainViewport.Camera = Camera_Details(maxpoint);
            mainViewport.Children.Add(ModelVisual3D_Details(maxpoint));
            Model3DGroup cube = new Model3DGroup();
            Point3D[] points = new Point3D[data.GetLength(0) * data.GetLength(1)];
            TransformPoints(data, points);
            List<Triangulator.Geometry.Point> points2d = Points3dtoPoints2d(points);
            if (points2d.Count > 2)
            {
                List<Triangulator.Geometry.Triangle> tris = Triangulator.Delauney.Triangulate(points2d);
                foreach (Triangulator.Geometry.Triangle t in tris)
                {
                    string s1 = points2d[t.p1].X.ToString() + points2d[t.p1].Y.ToString();
                    string s2 = points2d[t.p2].X.ToString() + points2d[t.p2].Y.ToString();
                    string s3 = points2d[t.p3].X.ToString() + points2d[t.p3].Y.ToString();
                    Point3D p1 = (Point3D)delaunaypoints[s1];
                    Point3D p2 = (Point3D)delaunaypoints[s2];
                    Point3D p3 = (Point3D)delaunaypoints[s3];
                    cube.Children.Add(CreateTriangleModel(p2, p1, p3));

                }
            }
            ModelVisual3D model = new ModelVisual3D();
            model.Content = cube;


            this.mainViewport.Children.Add(model);
            activeCanvas = new Canvas();
            activeCanvas.Tag = "plot3D_Terrain";
            mainViewport.ClipToBounds = true;
            activeCanvas.Children.Add(mainViewport);
            pm.Convert_to_Image(activeCanvas, -2);

        }

        //Return list to UI Team
        public List<double> return_list_default_values()
        {
            return default_valus;
        }

        //Find Maximum point value among data to set camera at that position
        private double max_point_3D(double[,] data)
        {
            double maxpoint;
            maxpoint = data[0, 0];
            for (int i = 0; i < data.GetLength(0); i++)
            {
                for (int j = 0; j < data.GetLength(1); j++)
                {
                    if (maxpoint < data[i, j])
                        maxpoint = data[i, j];
                    else
                        continue;

                }
            }

            return maxpoint;
        }

        //subplot 3D 
        public void subplot3D_terrain(double[,] data, int paneno)
        {
            double maxpoint = max_point_3D(data);
            //default_valus.Add(-2);
            mainViewport = new Viewport3D();
            this.mainViewport.Height = actcanheight/2;
            this.mainViewport.Width = actcanwidth/2;

            mainViewport.Camera = Camera_Details(maxpoint);
            mainViewport.Children.Add(ModelVisual3D_Details(maxpoint));
            Model3DGroup cube = new Model3DGroup();
            Point3D[] points = new Point3D[data.GetLength(0) * data.GetLength(1)];
            TransformPoints(data, points);
            List<Triangulator.Geometry.Point> points2d = Points3dtoPoints2d(points);
            if (points2d.Count > 2)
            {
                List<Triangulator.Geometry.Triangle> tris = Triangulator.Delauney.Triangulate(points2d);
                foreach (Triangulator.Geometry.Triangle t in tris)
                {
                    string s1 = points2d[t.p1].X.ToString() + points2d[t.p1].Y.ToString();
                    string s2 = points2d[t.p2].X.ToString() + points2d[t.p2].Y.ToString();
                    string s3 = points2d[t.p3].X.ToString() + points2d[t.p3].Y.ToString();
                    Point3D p1 = (Point3D)delaunaypoints[s1];
                    Point3D p2 = (Point3D)delaunaypoints[s2];
                    Point3D p3 = (Point3D)delaunaypoints[s3];
                    cube.Children.Add(CreateTriangleModel(p2, p1, p3));

                }
            }
            
            ModelVisual3D model = new ModelVisual3D();
            model.Content = cube;


            this.mainViewport.Children.Add(model);
            activeCanvas = new Canvas();
            activeCanvas.Tag = "subplot3D_Terrain";
            activeCanvas.Height = actcanheight/2;
            activeCanvas.Width = actcanwidth/2;
            mainViewport.ClipToBounds = true;
            activeCanvas.Children.Add(mainViewport);
            pm.Convert_to_Image(activeCanvas, paneno);


        }

        //convert matrix points to point3D
        private void TransformPoints(double[,] data, Point3D[] points)
        {
            int count = 0;
            for (int i = 0; i < data.GetLength(0); i++)
            {
                for (int j = 0; j < data.GetLength(1); j++)
                {
                    points[count] = new Point3D(i-5, j-5, data[i, j]);
                    count += 1;
                }
            }
        }

        //creates triangle model 
        private Model3DGroup CreateTriangleModel(Point3D p0, Point3D p1, Point3D p2)
        {
            MeshGeometry3D mesh = new MeshGeometry3D();
            Vector3D normal;
            // Vector3D normal1;
            //Vector3D normal2;
            normal = CalculateNormal(p0, p1, p2);
            if (normal.Y >= 0)
            {
                mesh.Positions.Add(p0);
                mesh.Positions.Add(p1);
                mesh.Positions.Add(p2);
                mesh.TriangleIndices.Add(0);
                mesh.TriangleIndices.Add(1);
                mesh.TriangleIndices.Add(2);
                mesh.Normals.Add(normal);
                mesh.Normals.Add(normal);
                mesh.Normals.Add(normal);
            }
            else
            {
                normal = CalculateNormal(p1, p2, p0);
                if (normal.Y > 0)
                {
                    mesh.Positions.Add(p1);
                    mesh.Positions.Add(p2);
                    mesh.Positions.Add(p0);
                    mesh.TriangleIndices.Add(1);
                    mesh.TriangleIndices.Add(2);
                    mesh.TriangleIndices.Add(0);
                    mesh.Normals.Add(normal);
                    mesh.Normals.Add(normal);
                    mesh.Normals.Add(normal);
                }
                else
                {
                    normal = CalculateNormal(p2, p1, p0);
                    mesh.Positions.Add(p2);
                    mesh.Positions.Add(p1);
                    mesh.Positions.Add(p0);
                    mesh.TriangleIndices.Add(2);
                    mesh.TriangleIndices.Add(1);
                    mesh.TriangleIndices.Add(0);
                    mesh.Normals.Add(normal);
                    mesh.Normals.Add(normal);
                    mesh.Normals.Add(normal);
                }
            }


            Material material = new DiffuseMaterial(
                new SolidColorBrush(Colors.LawnGreen));
            //DiffuseMaterial material = new DiffuseMaterial(myHorizontalGradient);
            GeometryModel3D model = new GeometryModel3D(
                mesh, material);
            // RotateTransform3D myrotate = new RotateTransform3D();
            // Apply a transform to the object. In this sample, a rotation transform is applied,  
            // rendering the 3D object rotated.

            RotateTransform3D myRotateTransform3D = new RotateTransform3D();
            AxisAngleRotation3D myAxisAngleRotation3d = new AxisAngleRotation3D();
            // myAxisAngleRotation3d.Axis = new Vector3D(2, 2, 2);
            if (userdefcamdet.Count != 0)
            {
              //  myAxisAngleRotation3d.Axis = new Vector3D(userdefcamdet[13],userdefcamdet[14],userdefcamdet[15]);
                myAxisAngleRotation3d.Angle = userdefcamdet[12];

            }
            else
            {
                if(default_valus.Count==10)
                default_valus.RemoveAt(default_valus.Count - 1);
                myAxisAngleRotation3d.Angle = 0;
                default_valus.Add(0);
            }
            myRotateTransform3D.Rotation = myAxisAngleRotation3d;
            model.Transform = myRotateTransform3D;

            // Add the geometry model to the model group.
            // myModel3DGroup.Children.Add(myGeometryModel);

            // Add the group of models to the ModelVisual3d.
            // myModelVisual3D.Content = myModel3DGroup;

            // 
            // myViewport3D.Children.Add(myModelVisual3D);
            Model3DGroup group = new Model3DGroup();
            group.Children.Add(model);
            return group;


        }

        //calculates the normal to each triangle surface
        private Vector3D CalculateNormal(Point3D p0, Point3D p1, Point3D p2)
        {
            Vector3D v0 = new Vector3D(
                p1.X - p0.X, p1.Y - p0.Y, p1.Z - p0.Z);
            Vector3D v1 = new Vector3D(
                p2.X - p1.X, p2.Y - p1.Y, p2.Z - p1.Z);
            return Vector3D.CrossProduct(v0, v1);
        }

        //set camera position
        private void SetCamera()
        {
            //PerspectiveCamera camera = (PerspectiveCamera)mainViewport.Camera;
            //Point3D position = new Point3D(
            //    Convert.ToDouble(cameraPositionXTextBox.Text),
            //    Convert.ToDouble(cameraPositionYTextBox.Text),
            //    Convert.ToDouble(cameraPositionZTextBox.Text)
            //);
            //Vector3D lookDirection = new Vector3D(
            //    Convert.ToDouble(lookAtXTextBox.Text),
            //    Convert.ToDouble(lookAtYTextBox.Text),
            //    Convert.ToDouble(lookAtZTextBox.Text)
            //);
            //camera.Position = position;
            //camera.LookDirection = lookDirection;
        }

        //clear previous terain from the viewport
        private void ClearViewport()
        {
            ModelVisual3D m;
            for (int i = mainViewport.Children.Count - 1; i >= 0; i--)
            {
                m = (ModelVisual3D)mainViewport.Children[i];
                if (m.Content is DirectionalLight == false)
                    mainViewport.Children.Remove(m);
            }
        }
        #endregion
        
    }
}

